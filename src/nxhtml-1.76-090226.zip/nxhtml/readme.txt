To install nXhtml put this in your .emacs:

   (load "YOUR-PATH-TO/nxhtml/autostart.el")

where autostart.el is the file in the same directory as this
readme.txt file.

Note: If you are using Emacs+EmacsW32 then nXhtml is already
installed.
